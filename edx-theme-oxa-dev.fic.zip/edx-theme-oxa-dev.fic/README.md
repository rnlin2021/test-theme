Overview
========
![CI Tags](https://travis-ci.org/Microsoft/edx-theme.svg?branch=master)

These are comprehensive theming folders

License
=======

The code in this repo is licensed under the Apache 2.0 License.
See [LICENSE.txt](LICENSE.txt) for more info.